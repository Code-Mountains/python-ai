# From ChatGPT to OpenAI

Prompts in ChatGPT

> What is an Large Language Model?

> Write a story about a traveling computer programmer

> Translate the story into Spanish