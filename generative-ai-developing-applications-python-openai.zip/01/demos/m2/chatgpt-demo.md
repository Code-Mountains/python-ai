# ChatGPT Demo

Try the following prompts

> What is your perspective on the ethical dilemmas surrounding artificial intelligence?

> Write a story about a time traveling computer programmer

> Translate the previous story into Spanish

> Write a function in Python to read JSON from a file

> Act as a Linux terminal. I will input Linux commands, and your response will be the terminal output shown in a single code block, nothing else. Do not provide explanations. 

```
ls
pwd
rm -rf *
```